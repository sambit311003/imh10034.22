import java.util.Scanner;

public class ASS9qs9 {
    public static void main(String[] args) {
        String Word= "lexicographically";
        for (int i = 0; i < Word.length(); i++) {
            System.out.println(Word.charAt(5));
        }


    }
}
