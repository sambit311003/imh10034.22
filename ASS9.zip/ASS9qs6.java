import java.util.Scanner;

public class ASS9qs6 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a String");
        //by mistake zero has been entered
        String A=sc.next();
        String NewStr = "";
        for (int i = 0; i < A.length(); i++) {
            if (A.charAt(i)=='0'){
                continue;
            }
            else
                //System.out.print(A.charAt(i));
                NewStr= String.valueOf(A.charAt(i));
                System.out.print(NewStr);

        }

    }
}
