import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Ass9qs3 {
    public static void main(String[] args) {
        ArrayList<Integer> arrA=new ArrayList<>();
        ArrayList<Integer>arrB=new ArrayList<>();
        Scanner sc=new Scanner(System.in);
        for (int i=0;i<5;i++){
            System.out.println("The element of arrA is:");
            arrA.add(sc.nextInt());
        }
        for (int i=0;i<5;i++){
            System.out.println("The element of arrB is:");
            arrB.add(sc.nextInt());
        }

        if(arrA.equals(arrB)){
            System.out.println("Both the arrays are equal");
        }
        else {
            System.out.println("Not equal");
        }
        System.out.println(arrA.clone());
        System.out.println(arrB.clone());
        //System.out.println(arrA.addAll(arrB));
        arrA.addAll(arrB);
        ArrayList<Integer>arr=new ArrayList<>();
        arr=(ArrayList)arrA.clone();
        System.out.println(arr);

        System.out.println("enter a number to be searched:");
        int a=sc.nextInt();
        for (int i=0;i<5;i++){
            if (arrA.get(i) ==a){
                System.out.println("Present");
            }else {
                System.out.println("Not present");
            }
        }
        System.out.println(Collections.max(arrA));
        System.out.println(Collections.min(arrA));
        System.out.println(Collections.max(arrB));
        System.out.println(Collections.min(arrB));
        System.out.println("Enter the index to be removed from arrA:");
        int b=sc.nextInt();
        arrA.remove(b);
        System.out.println(arrA);

    }
}
