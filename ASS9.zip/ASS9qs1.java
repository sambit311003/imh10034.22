import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

public class ASS9qs1 {
    public static void main(String[] args) {
        ArrayList <Integer>arr=new ArrayList<>();
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the array:");
        for (int i=0;i< 5;i++){
            System.out.println("The element is:");
            arr.add(sc.nextInt());

        }
        arr.add(0,8);
        System.out.println(arr);
        arr.remove(2);
        System.out.println(arr);
        System.out.println(arr.toString());
        Collections.sort(arr);
        System.out.println(arr);


    }
}
