import java.util.Scanner;

public class ASS9qs8 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the String:");
        String WordA= sc.next();
        System.out.println("enter the string:");
        String WordB=sc.next();
        System.out.println(WordA.equals(WordB));
        System.out.println(WordA.equalsIgnoreCase(WordB));
        System.out.println(WordA.compareTo(WordB));
    }
}
