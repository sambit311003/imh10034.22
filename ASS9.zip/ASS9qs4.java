import java.util.Scanner;

public class ASS9qs4 {
    public static void main(String[] args) {
        //Anagram
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the first word:");
        String WordA=sc.next();
        System.out.println("Enter the second word:");
        String WordB=sc.next();
        WordA.trim();
        WordB.trim();
        WordA.charAt(WordA.length());
        System.out.println(WordA);
//        for (int i = 0; i < ; i++) {
//
//        }

    }
}
