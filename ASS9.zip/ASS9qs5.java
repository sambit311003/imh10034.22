import java.util.Scanner;

public class ASS9qs5 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the string A:");
        String A= sc.next();
        System.out.println("enter the string B:");
        String B=sc.next();
        for (int i=0;i<A.length();i++){
            System.out.println(A.length());
            System.out.println(A.charAt(4));

        }
        for (int j=A.length()-1;j>0;j--){
            System.out.print(A.charAt(j));
        }

    }
}