class Rectangle{
    int length;
    int breadth;
//non-parameterized constructor
    public Rectangle() {
        this.length = 1;
        this.breadth = 1;

    }
//parameterized constructor
    public Rectangle(int length,int breadth) {
        this.length = length;
        this.breadth = breadth;
    }
}
class Cuboid extends Rectangle{
    int height;

    public Cuboid() {
        this.height = 1;
    }


    public Cuboid(int height) {
        this.height = height;
    }

    public int Volume(){
        return length*breadth*height;
    }
}


public class Ass7qs3 {
    public static void main(String[] args) {
        Cuboid obj=new Cuboid(5);
        System.out.println(obj.Volume());



    }
}
