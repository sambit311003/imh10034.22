class Circle{
    double Radius;
    int set_width;


    public double Area(double Radius){
        return 3.14*Radius*Radius;
    }

    public void setSet_width(int set_width) {
        this.set_width = set_width;
    }
    public double Circumference(int Radius){
        return 2*3.14*Radius;
    }

}
class Cylinder extends Circle{
    int height;
    public double volume(int height){
        return Area(3.5)*height;

    }

}


public class Ass7qs2 {
    public static void main(String[] args) {
        Circle obj=new Circle();
        System.out.println("Area: "+obj.Area(3.2));
        Circle obj1=new Circle();
        obj.setSet_width(5);
        System.out.println("circumference: "+obj1.Circumference(5));
        Cylinder obj2=new Cylinder();
        System.out.println("volume: "+obj2.volume(5));


    }
}
