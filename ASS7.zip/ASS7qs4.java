class Rectangle2{
    int length;
    int breadth;
    //non-parameterized constructor
    public Rectangle2() {
        this.length = 1;
        this.breadth = 1;

    }
    //parameterized constructor
    public Rectangle2(int length,int breadth) {
        this.length = length;
        this.breadth = breadth;
    }
}
class Cuboid1 extends Rectangle{
    int height;

    public Cuboid1() {
        this.height = 1;
    }


    public Cuboid1(int height) {
        this.height = height;
    }

    public int Volume(){
        return length*breadth*height;
    }
}


public class ASS7qs4 {
    public static void main(String[] args) {
        Cuboid obj=new Cuboid(5);
        System.out.println(obj.Volume());



    }
}

