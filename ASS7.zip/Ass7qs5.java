package PACKAGE_NAME;public class Ass7qs5 {
}
