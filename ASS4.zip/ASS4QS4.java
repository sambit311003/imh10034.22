import java.util.Scanner;

class Student4{
    int student_roll;
    String student_name;
    int student_marks;

    int []Marks=new int[5];

    public Student4(String student_name,int student_roll,int marks1,int marks2,int marks3,int marks4,int marks5) {
        this.student_name = student_name;
        this.student_roll = student_roll;
        this.Marks[0]=marks1;
        this.Marks[1]=marks2;
        this.Marks[2]=marks3;
        this.Marks[3]=marks4;
        this.Marks[4]=marks5;


    }

    public static int Average_Marks(int Average, int[] Marks,int sum){
        for (int i = 0; i< Marks.length; i++){
            sum=sum+Marks[i];


        }
        return sum/5;



    }




}




public class ASS4QS4 {
    public static void main(String[] args) {

        Student4 student1=new Student4("Saikat",456,89,86,45,76,15);
        Student4 student2=new Student4("Sankat",46,89,86,45,76,15);
        Student4 student3=new Student4("Saket",86,89,86,45,76,15);

        



    }
}
