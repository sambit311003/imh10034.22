class Car{
    public String Brand;


    public Car(String brand) {
        Brand = "Ford";
    }

    public String getBrand() {
        return Brand;
    }

    public void setBrand(String brand) {
        Brand = brand;
    }
}



public class ASS4QS2 {
    public static void main(String[] args) {
        Car in=new Car("Ford");
        System.out.println(in.getBrand());


    }
}
