/*Write a program to print the names of students by creating a Student class.
The student class has data member as student_roll, student_name, and
student_marks in five different subjects. If no name is passed while
creating an object of Student class, then the name should be "Unknown",
otherwise the name should be equal to the String value passed while
creating object of Student class. Similarly, if the student roll is not
initialised then it will be zero and the same applies to the marks. Create
one parameterized constructor and another non parameterized constructor to
initialise the values in the array for the above-mentioned task. Create
two object for the class and display their values using the suitable method.*/


import java.util.Scanner;

class Student{
    int student_roll;
    String student_name;
    int student_marks;
//parameterized constructor
//Make it empty it will become non parametrised constructor
    public Student(String student_name,int student_marks,int student_roll) {
        this.student_name = "Unknown";
        this.student_roll=0;
        this.student_marks=0;

    }

    public int getStudent_roll() {
        return student_roll;
    }

    public void setStudent_roll(int student_roll) {
        this.student_roll = student_roll;
    }
}






public class ASS4QS3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Student Name:");
        String student_name=sc.next();
        System.out.println("Enter Student Roll number:");
        int student_roll= sc.nextInt();
//        System.out.println("Enter marks of student in Science:");
//        int student_marks_science= sc.nextInt();
//        System.out.println("Enter marks of student in Maths:");
//        int student_marks_Maths= sc.nextInt();
//        System.out.println("Enter marks of student in English:");
//        int student_marks_Eng= sc.nextInt();
//        System.out.println("Enter marks of student in Robotics:");
//        int student_marks_Robotics= sc.nextInt();
//        System.out.println("Enter marks of student in Artificial Intelligence:");
//        int student_marks_AI= sc.nextInt();
        System.out.println("Enter Marks of Student:");
        int student_marks=sc.nextInt();
        Student in=new Student(student_name,student_roll,student_marks);




    }
}
