class Employee{
    private int Employee_id;
    private String Employee_name;
    private String Employee_department;


    public int getEmployee_id() {
        return Employee_id;
    }

    public void setEmployee_id(int employee_id) {
        Employee_id = employee_id;
    }

    public String getEmployee_name() {
        return Employee_name;
    }

    public void setEmployee_name(String employee_name) {
        Employee_name = employee_name;
    }

    public String getEmployee_department() {
        return Employee_department;
    }

    public void setEmployee_department(String employee_department) {
        Employee_department = employee_department;
    }
}


public class ASS4QS1 {
    public static void main(String[] args) {
        //object creation
        Employee in=new Employee();
        in.setEmployee_id(578);
        in.setEmployee_name("Sailboat");
        in.setEmployee_name("Quality");
        System.out.println(in.getEmployee_id());
        System.out.println(in.getEmployee_name());
        System.out.println(in.getEmployee_department());



    }
}
