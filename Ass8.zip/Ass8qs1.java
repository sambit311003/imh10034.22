class TKT{
    static class InnerClass{
        public void Display(){
            System.out.println("Running Innerclass");
        }
        static class StaticNestedClass{
            public void Display(){
                System.out.println("Running Static Nested class");
            }
        }
    }
}






public class Ass8qs1 {
    public static void main(String[] args) {
        TKT obj0= new TKT();
        TKT.InnerClass obj1= new TKT.InnerClass();
        obj1.Display();
        TKT.InnerClass.StaticNestedClass obj2=new TKT.InnerClass.StaticNestedClass();
        obj2.Display();
    }
}
