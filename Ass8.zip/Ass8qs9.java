interface Helper{
    abstract void Method1();
    default void Method2(){
        System.out.println("I am a Helper");
    }
}

interface ClassHelper extends Helper{
    abstract void Method2();

}
class Idot implements ClassHelper{

    @Override
    public void Method2() {

    }

    @Override
    public void Method1() {

    }
}




public class Ass8qs9 {
    public static void main(String[] args) {
        Idot obj0=new Idot();
        obj0.Method1();
        obj0.Method2();
        Helper obj1=new Idot();
        obj1.Method1();
    }
}
