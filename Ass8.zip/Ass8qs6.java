abstract class Phone{
    abstract void call();
    abstract void sms();


}
interface camera{

    default void click(){
        System.out.println("Click");
    }
    default void record(){
        System.out.println("Record");
    }

}

interface MusicPlayer{
    default void Play(){
        System.out.println("Play");
    }
    default void Pause(){
        System.out.println("Pause");
    }
    default void stop(){
        System.out.println("Stop");
    }

}

class Smartphone implements camera{
    @Override
    public void click() {
        camera.super.click();
    }

    @Override
    public void record() {
        camera.super.record();
    }

}




public class Ass8qs6 {
    public static void main(String[] args) {
        Smartphone obj0=new Smartphone();
        obj0.click();
        obj0.record();


    }
}
