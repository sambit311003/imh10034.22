interface one{
    abstract void method1();
    default void Display(){
        System.out.println("Interface One");

    }
    void Display1();


}
interface Two{
    abstract void method1();
    default void Display(){
        System.out.println("Interface One");

    }
}

class ThreeClass implements one,Two{

    @Override
    public void method1() {

    }

    @Override
    public void Display() {
        one.super.Display();
    }

    @Override
    public void Display1() {

    }

}



public class Ass8qs7 {
    public static void main(String[] args) {
        ThreeClass obj0=new ThreeClass();
        obj0.Display();
        obj0.method1();
        one obj1=new ThreeClass();
        Two obj2=new ThreeClass();
        obj1.Display();
        obj2.Display();
    }
}
