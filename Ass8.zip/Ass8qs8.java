interface integer{
    int a = 0;


    default void  Method1(){
        System.out.println("I am method 1");
    }
    static void Method2(){
        System.out.println("I am method 2");
    }
}
class One implements integer{
    void Display(int a){
        System.out.println("the value of a is:"+a);

    }
}



public class Ass8qs8 {
    public static void main(String[] args) {
        One obj0=new One();
        obj0.Display(7);
        integer obj1=new One();
        obj1.Method1();
        //obj1.Method2();
    }
}
