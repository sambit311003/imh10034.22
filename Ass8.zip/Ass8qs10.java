interface HelperA{
    interface HelperB{
        default void Method(){
            System.out.println("hello");
        }
    }
}
class IdotA implements HelperA, HelperA.HelperB {
    @Override
    public void Method() {
        HelperB.super.Method();
    }
}


public class Ass8qs10 {
    public static void main(String[] args) {
        IdotA obj0=new IdotA();
        obj0.Method();
    }
}
