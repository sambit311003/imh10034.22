abstract class  ShapeA{
    abstract void Perimeter();
    abstract void Area();



}
class CircleA extends ShapeA{
    int radius;

    @Override
    void Perimeter() {

    }

    @Override
    void Area() {

    }

    public int Area(int radius) {
        return (int) (3.14*radius*radius);

    }
}

class RectangleA extends ShapeA{

    @Override
    void Perimeter() {

    }

    @Override
    void Area() {

    }
}





public class Ass8qs3 {
    public static void main(String[] args) {
        RectangleA obj0=new RectangleA();
        obj0.Area();
        obj0.Perimeter();
        CircleA obj1=new CircleA();
        //obj1.Area(8);
        System.out.println(obj1.Area(8));


    }
}
