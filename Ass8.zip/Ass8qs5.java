abstract class Base1{
    static abstract class Base2{
        abstract void Display();
    }
}
class Derived1 extends Base1{
    static class Derived2 extends Base2{

        @Override
        void Display() {
            System.out.println("Hey");
        }
    }
}



public class Ass8qs5 {
    public static void main(String[] args) {
        Base1 obj0=new Derived1();
        Derived1.Derived2 obj1=new Derived1.Derived2();
        obj1.Display();
    }
}
