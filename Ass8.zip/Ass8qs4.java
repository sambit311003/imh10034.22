

interface Person {
    public void abc();

}
class EmployeeA implements Person{
    @Override
    public void abc() {
        System.out.println("I am the method where interface Person has been implemented");

    }


//abstract void Display(int empId, String emp_name);

}


    public  class Ass8qs4 {
    public static void main(String[] args) {
        EmployeeA obj0=new EmployeeA();
        obj0.abc();


    }
}
