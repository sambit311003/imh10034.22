abstract class Bike{
      abstract void run();
}
class Honda extends Bike{
    @Override
    void run() {
        System.out.println("Hero Honda");
    }
}





public class Ass8qs2 {
    public static void main(String[] args) {
        Bike obj=new Honda();
        Honda obj1= new Honda();
        obj.run();
        obj1.run();
    }
}
