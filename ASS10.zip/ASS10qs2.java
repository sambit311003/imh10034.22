class EmployeeD {
    private static int nextId = 1000;
    private final int id;
    private final String name;
    private final int age;

    public EmployeeD(String name, int age) {
        this.id = nextId++;
        this.name = name;
        this.age = age;
    }

    public void show() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }

    public static void showNextId() {
        System.out.println("Next Employee ID: " + nextId);
    }

    public static int getNextId() {
        return nextId;
    }

    public static void setNextId(int nextId) {
        EmployeeD.nextId = nextId;
    }
}

public class ASS10qs2 {
    public static void main(String[] args) {
        System.out.println("Actual employee count: " + EmployeeD.getNextId());


        EmployeeD emp1 = new EmployeeD("Saikat", 30);
        EmployeeD emp2 = new EmployeeD("Sambit", 25);


        System.out.println("Employee 1:");
        emp1.show();
        System.out.println();

        System.out.println("Employee 2:");
        emp2.show();
        System.out.println();


        EmployeeD.showNextId();
        System.out.println();


        EmployeeD.setNextId(EmployeeD.getNextId() + 10);
        System.out.println("Actual employee count after interns: " + EmployeeD.getNextId());


        EmployeeD.showNextId();
        System.out.println();


        emp1 = null;
        emp2 = null;
        System.gc();


        System.out.println("Final employee count: " + EmployeeD.getNextId());
    }
}