class qs01{
    public void finalize(){
        System.out.println("Final");

    }
}





public class ASS1qs1 {
    public static void main(String[] args) {
        qs01 obj1=new qs01();
        qs01 obj2=new qs01();
        obj1=null;
        obj2=null;

        System.gc();







    }
}
