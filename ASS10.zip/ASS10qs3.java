import java.util.Scanner;

public class ASS10qs3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n= sc.nextInt();
        int[] arr =new int[n];
        for(int i=0;i<n;i++)
        {
            arr[i]=sc.nextInt();
        }
        try
        {
            for(int j=0;j<arr.length;j++)
            {
                System.out.println(arr[j]/arr[j+1]);
            }
        }
        catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("An exception is there " + e);
        }
        catch(ArithmeticException e)
        {
            System.out.println(e);
        }
    }
}