import java.io.*;

public class Q3 {
    public static void main(String[] args) {
        // Define the filenames
        String sourceFileName = "source.txt";
        String destinationFileName = "destination.txt";
        String outputFileName = "output.txt";

        // Using try-with-resources to ensure the streams are closed properly
        try (FileReader reader1 = new FileReader(sourceFileName);
             BufferedReader br1 = new BufferedReader(reader1);
             FileReader reader2 = new FileReader(destinationFileName);
             BufferedReader br2 = new BufferedReader(reader2);
             FileWriter writer = new FileWriter(outputFileName)) {

            // Reading from source.txt
            String line;
            while ((line = br1.readLine()) != null) {
                writer.write(line + "\n");
            }

            // Reading from destination.txt
            while ((line = br2.readLine()) != null) {
                writer.write(line + "\n");
            }

            System.out.println("Content from source.txt and destination.txt copied to output.txt successfully.");

        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
