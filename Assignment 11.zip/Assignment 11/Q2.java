import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

class Q2 {
    public static void main(String[] args) {
        // Specify the path of the file to read
        String filePath = "example.txt";

        try {
            // Read the file into a byte array
            byte[] byteArray = readFromFile(filePath);

            // Print the content of the byte array (just for demonstration)
            System.out.println("Contents of the file as byte array:");
            for (byte b : byteArray) {
                System.out.print(b + " ");
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
    }

    private static byte[] readFromFile(String filePath) throws IOException {
        // Create a FileInputStream to read from the file
        FileInputStream fileInputStream = new FileInputStream(new File(filePath));

        // Get the size of the file
        long fileSize = new File(filePath).length();

        // Create a byte array to store the file content
        byte[] byteArray = new byte[(int) fileSize];

        // Read the file content into the byte array
        fileInputStream.read(byteArray);

        // Close the FileInputStream
        fileInputStream.close();

        return byteArray;
    }
}
