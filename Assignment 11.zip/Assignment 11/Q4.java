import java.io.*;

public class Q4 {
    public static void main(String[] args) {
        // Define the filenames
        String sourceFileName = "source.txt";
        String destinationFileName = "destination.txt";

        // Create input streams for source.txt and destination.txt
        try (FileInputStream fis1 = new FileInputStream(sourceFileName);
             FileInputStream fis2 = new FileInputStream(destinationFileName);
             SequenceInputStream sequenceInputStream = new SequenceInputStream(fis1, fis2)) {

            // Create a StringBuilder to store the combined content
            StringBuilder content = new StringBuilder();

            // Read from the combined input stream
            int data;
            while ((data = sequenceInputStream.read()) != -1) {
                // Append the read character to the content StringBuilder
                content.append((char) data);
            }

            // Display the combined content
            System.out.println("Combined File Content:");
            System.out.println(content.toString());

        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}

