import java.io.*;
public class Q1 {
    public static void main(String[] args) {
        // Create a BufferedReader to read input from the user
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        // Prompt the user to enter some lines
        System.out.println("Enter some lines (type 'exit' to stop):");

        // Create a StringBuilder to store the lines
        StringBuilder lines = new StringBuilder();

        try {
            // Read lines until the user types 'exit'
            String line;
            while (!(line = reader.readLine()).equalsIgnoreCase("exit")) {
                lines.append(line).append("\n");
            }

            // Close the BufferedReader
            reader.close();

            // Write the lines to a file
            writeToFile(lines.toString(), "output.txt");

            System.out.println("Lines have been written to output.txt");
        } catch (IOException e) {
            System.err.println("Error reading input: " + e.getMessage());
        }
    }

    private static void writeToFile(String content, String filename) throws IOException {
        // Create a BufferedWriter to write to the file
        BufferedWriter writer = new BufferedWriter(new FileWriter(filename));

        // Write the content to the file
        writer.write(content);

        // Close the BufferedWriter
        writer.close();
    }
}
