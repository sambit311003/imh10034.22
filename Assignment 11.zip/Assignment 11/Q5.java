import java.io.*;

public class Q5 {
    // Method to append content to a file
    public static void appendToFile(String fileName, String content) {
        try (FileWriter writer = new FileWriter(fileName, true)) {
            writer.write(content);
            System.out.println("Content appended to " + fileName + " successfully.");
        } catch (IOException e) {
            System.err.println("Error appending content to " + fileName + ": " + e.getMessage());
        }
    }

    // Method to overwrite content of a file
    public static void overwriteFile(String fileName, String content) {
        try (FileWriter writer = new FileWriter(fileName, false)) {
            writer.write(content);
            System.out.println("Content overwritten in " + fileName + " successfully.");
        } catch (IOException e) {
            System.err.println("Error overwriting content in " + fileName + ": " + e.getMessage());
        }
    }

    // Method to delete a file
    public static void deleteFile(String fileName) {
        File file = new File(fileName);
        if (file.delete()) {
            System.out.println(fileName + " deleted successfully.");
        } else {
            System.err.println("Failed to delete " + fileName);
        }
    }

    public static void main(String[] args) {
        // Test the methods
        String fileName = "example.txt";
        String contentToAppend = "\nThis is appended content.";
        String contentToOverwrite = "This is overwritten content.";

        // Append content to the file
        appendToFile(fileName, contentToAppend);

        // Overwrite content of the file
        overwriteFile(fileName, contentToOverwrite);

        // Delete the file
        deleteFile(fileName);
    }
}
