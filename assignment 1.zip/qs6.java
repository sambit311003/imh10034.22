import java.util.Scanner;

public class qs6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();

        int[] originalArray = new int[n];
        System.out.println("Enter the elements in the array in random order:");
        for (int i = 0; i < n; i++) {
            originalArray[i] = scanner.nextInt();
        }

        int evenCount = 0;
        int oddCount = 0;

        for (int num : originalArray) {
            if (num % 2 == 0) {
                evenCount++;
            } else {
                oddCount++;
            }
        }

        int[] evenArray = new int[evenCount];
        int[] oddArray = new int[oddCount];

        int evenIndex = 0;
        int oddIndex = 0;

        for (int num : originalArray) {
            if (num % 2 == 0) {
                evenArray[evenIndex++] = num;
            } else {
                oddArray[oddIndex++] = num;
            }
        }

        System.out.println("\nOriginal Array:");
        displayArray(originalArray);

        System.out.println("\nEven Array:");
        displayArray(evenArray);

        System.out.println("\nOdd Array:");
        displayArray(oddArray);

        scanner.close();
    }

    private static void displayArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
